<template>
  <h1>TODO it!</h1>
</template>

<script>
export default {};
</script>

<style scoped>
/* scoped -vue에서만 있는 속성, 스타일 정의를 해당 컴포넌트에서만 적용 */
h1 {
  font-family: "GmarketSansBold", sans-serif;
  color: #2e343e;
}
</style>