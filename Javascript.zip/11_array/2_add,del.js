const food = ['🍕', '🍔','🍟','🥨'];   //리터럴 이용

console.log(food);
//배열 아이템을 참조하는(선택) 방법
console.log(food[0]);     //피자
console.log(food[3]);     //프레첼
console.log(food.length);   

for(let i = 0; i < food.length; i++){
  console.log(food[i]);
}


//아이템 추가, 삭제, 수정
//인덱스로 접근하는 방법은 좋지 않음
//const food = ['🍕', '🍔','🍟','🥨']; 

food[6] = '🍗';     //차례대로 들어가는게 아니라 중간에 빈 아이템이 있는 상태로 추가
console.log('닭다리 추가', food);  
food[food.length] = '🧇';   //확실하게 마지막에 추가하고 싶을때
console.log('와플 추가', food);

food[2] = '🥚'; 
console.log('달걀 추가3번째', food);

delete food[1];
console.log('2번째 아이템 삭제', food);

