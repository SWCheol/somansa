//배열의 함수들 정리
const fruits = ['🍇','🍎','🍋'];

//특정한 오브젝트가 배열인지 아닌지 체크
console.log(Array.isArray(fruits)); 
console.log(Array.isArray({}));     //빈오브젝트 전달- false


//특정한 아이템의 위치를 찾을때(인덱스)  - 배열명.indexOf(아이템)
console.log('🍋의 인덱스는?',fruits.indexOf('🍋')); 

//배열안에 특정한 아이템이 있는지 체크
console.log('🍎 있니?',fruits.includes('🍎')); 
console.log('🍍 있니?',fruits.includes('🍍')); 

//아이템 추가 - 제일 뒤에  
fruits.push('🍑','🍑');       //여러개 추가도 가능, 배열을 업데이트
console.log('🍑추가', fruits);

//아이템 추가 - 제일 앞에
fruits.unshift('🍺');
console.log('🍺추가', fruits);
console.log('아이템 갯수는?',fruits.length);

//제거  -제일 뒤
fruits.pop();
console.log('pop()을 이용해서 삭제',fruits);

//제거 - 제일 앞
fruits.shift();
console.log('shift()을 이용해서 삭제',fruits);


//중간 아이템 추가 또는 삭제
fruits.splice(0,1);     //2번(세번째)인덱스 1개 삭제
console.log('중간을 삭제',fruits);
//splice(시작인덱스,삭제될 갯수)  -삭제될 갯수가 생략될때는 뒤에있는거 전부다 삭제

fruits.splice(1,1,'🍒','🍌'); 
console.log('삭제하고 그자리에 추가',fruits);
//splice(시작인덱스,삭제될 갯수,추가될 아이템....)

console.log('============================================')


//기존배열에서 새로운 배열 잘라와서 만듦
let newFr =fruits.slice(1,3);
console.log('새로운 배열 만듦',newFr);
//.slice(시작지점, 마지막지점(몇번째인지))

newFr = fruits.slice(-2);   //뒤에서 부터 2개 아이템
console.log('-값 이용',newFr);

//여러개의 배열을 붙여줌(합쳐줌)
const arr1 = [1,2,3];
const arr2 = [100,200,300];
const arr3 = arr1.concat(arr2);
console.log('arr1',arr1);
console.log('arr2',arr2);
console.log('arr3',arr3);

//순서를 거꾸로
const arr4 = arr3.reverse(); 
console.log('arr4-순서를 꺼꾸로',arr4);

//특정한 값으로 배열 아이템 채우기
arr4.fill('🌼');
console.log('arr4',arr4);

arr4.fill('🥩',1,3); 
console.log('arr4',arr4);
//fill(채울꺼, 시작인덱스, 끝나는 지점(몇번째냐))

arr4.fill('🍻',3);    //fill(채울꺼, 시작인덱스~끝까지)
console.log('arr4',arr4);


//배열을 문자열로 합하기
const arr5 = ['하늘', '🌼', '1004', '💘', 'friday','바다']
console.log('arr5는??', arr5);

let text = arr5.join();    //자동으로 ,(콤마) 를 이용해 문자로 변화
console.log(text);

text = arr5.join(' | ');    
console.log(text);


//중첩된 배열, 하나의 배열로 쫙 펴기
const arr6 =[[ '🌼', '💘', '🚲'],[1,2,3,4]]
console.log('중첩된 배열',arr6);
arr7 = arr6.flat();

console.log('arr7은?',arr7);  
//1단계까지 풀어줌, 배열안에 배열이 또 있을경우는 숫자(단계)를 넣어준다


//아이템을 특정 값으로 채우기
arr7.fill('🌹')
console.log('장미꽃으로 채워주기',arr7);


arr7.fill('a',1, 3);  //인덱스1부터, 세번째까지
console.log('장미꽃으로 채워주기',arr7);

arr7.fill('🥃',2);   //인덱스2부터 끝까지
console.log('맥주잔으로 채워주기',arr7);





















