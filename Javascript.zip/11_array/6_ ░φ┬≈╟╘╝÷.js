/*
  == 배열을 사용하는 함수들 ==
  일급함수(first-class function) - 일반 객체(변수) 처럼 사용
  고차함수(higher-order function) - 다른 함수를 인자로 받거나 반환. 절차형이 아니 함수들끼리 엮어 놓음

  forEach / find / findIndex / some / every / filter / map / flatMap / sort
  */


const fruits = ['🍌', '🍉', '🍒', '🍏'];

/*
for(let i = 0; i < fruits.length; i++){
  console.log(fruits[i]);
}*/

fruits.forEach( function(vv,aa,cc){ 
  console.log(vv);
  console.log(aa);
  console.log(cc);  
});
//고차함수 forEach 사용  (배열의요소, 요소의순서(index), 배열전체)
// 배열을 돌면서 (콜백함수)가 작동, 배열의 아이마다 한번식

/* value만 필요할때 화살표 함수로 생략
fruits.forEach((vv) => 
  console.log(vv);
);
*/
fruits.forEach((vv) => console.log(vv)); 

const item1 = { name:'🍔', price:2500 };
const item2 = { name:'🍩', price:1000 };
const item3 = { name:'🍰', price:400 };
const products = [ item1, item2, item3, item2 ];

//도넛을 찾을꺼야 
// let found = products.find(function(value){ 
//   return value.name == '🍩';
// });

let found = products.find((value) => value.name == '🍩');
//축약
console.log('도넛찾음!!',found);

found = products.findIndex((value) => value.name == '🍩');
console.log('도넛의 인덱스값?',found);

/*
  find : 제일 먼저 나오는 조건에 맞는 아이템을 반환   
  findIndex : 제일 먼저 나오는 조건에 맞는 아이템의 인덱스를 반환  
*/

let result = products.some((value) => 
  value.name == '🍩'
);  //실행구가 1개일때는 {} 생략가능, 이때는 return필요없음
console.log('도너츠가 하나라도 있니?',result);

result = products.every((value) => value.name == '🍩');
console.log('전부 도너츠니?',result);
// some() - 하나라도 있으면 True(블린값). 화살표 함수로
// every() - 배열의 특정 부분이 모든 같은지 확인

result = products.filter((value) => value.name == '🍩');
console.log('도너츠가 들어있는 모든 아이템',result);
//filter()  조건에 맞는 아이템을 새로운 배열로 만들어줌
console.log('===========================================');


const nums = [1, 2, 3, 4, 5];
result = nums.map(function(item){
  return item*2;
})
console.log('map을 이용해봅시다',result);
//map() :배열의 아이템들을 각각 다른 아이템으로 매핑. 새로운 배열 생성

result = nums.map(function(item){   // 짝수인 경우만 2배로 맵핑
  if(item % 2 === 0){
    return item*2;
  } else {
    return item
  }
})
console.log('조건문 추가된 map을 이용해봅시다',result);

result = nums.map((item) => ['🍕','🥤'] );
console.log('각각의 배열아이템을 새로운 내용(배열)으로',result);

result = nums.flatMap((item) => ['🥦','🥒'] );
console.log('flatMap 이용해봅시다',result);
//flatMap : 중첩된 배열을 낱개로 만들어서 새로운 배열로  


//응용
result = ['sunday', 'morning'].map((ttt) => ttt.split(''));
console.log('문자열배열을 map',result);
// [[ 's', 'u', 'n', 'd', 'a', 'y' ],['m', 'o', 'r','n', 'i', 'n','g']]

result = ['blue', 'ocean'].flatMap((ttt) => ttt.split(''));
console.log('문자열배열을 flatMap',result);
// 알파벳 하나씩 배열값으로

//sort : 배열의 아이템들을 정렬
// 문자열 형태의 오름차순(1,2,3,4...., a,b,c...)으로 요소를 정렬
//기존의 배열을 변경(새로만드는거 x)
const texts = ['zoo', 'hi', 'abc',];
texts.sort();
console.log('sort를 호출',texts);  //알파벳 순서대로 오름차순

const numbers = [ 10, 8, 5, 1, 15, 3];
numbers.sort();
console.log('numbers배열을 sort',numbers); //문자열 형태로 10이 5보다 먼저 나옴

numbers.sort((a,b) => a-b);  
console.log('(a,b) => a-b 이용해서  sort',numbers);
//(a,b) => a-b  :순서대로 a,b에 넣고 위치를 이동시켜서 올림차순으로 만든다. 내부적인 알고리즘이 작동



