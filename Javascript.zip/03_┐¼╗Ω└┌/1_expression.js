/*
표현식 (expression)   - 수식, 값으로 평가 될 수 있는 문  ex) 2+3
*/

let b;    //선언문
b = 5;    //표현식, 할당문

let a = b = 3; 
console.log(a);