/*
  (대소관계)비교연산자  Relational Operator
  >   <   >=   <=    

  일치연산자
  =   A = B     -B를 A에 할당한다(대입)
  ==   A == B     -일치한다는 의미(타입은 구분 안함)   
  ===  A === B    -타입도 일치(염격한 비교)

  동등비교관계 연산자
  !=   A != B     -A와 B는 같지 않을때 true
  !==  A !== B    -A와 B가 type이나 값이(or) 다를때 true  
*/

console.log('5는 7보다 큰가요? ',5>7);      // false
console.log('5는 7보다 작은가요? ',5<7);    //true
console.log('5는 7보다 크거나 같은가요? ', 5 >= 7);    //true
console.log('5는 5보다 크거나 같은가요? ', 5 >= 5);    //true

//console.log('5와 5는 같나여? ', 5 = 5 );    //대입연산자 같다는 의미 X
console.log('5와 5는 같나여? ', 5 == 5 ); 
console.log("5와 '5'는 같나여? == ", 5 == '5' );   //문자열,숫자열 구분X -일치

console.log("5와 '5'는 같나여? ===", 5 === '5' );   //문자열, 숫자열 구분
console.log("5와 5는 같나여? ===", 5 === 5 );    

console.log("강남구와 서초구는 다른가여? (부정형)", '강남구' != '서초구 '); 
console.log('5와 5는 다른가요? ', 5 !== 5 );   //타입이 같음
console.log('5와 5는 다른가요? ', 5 !== '5');   //타입이 다름

// 같지 않을때가 true


const obj1 = { name:'js'};  //객체
const obj2 = { name:'js'};

console.log('obj1과 obj2는 같은가요? ==', obj1 == obj2);
//메모리 주소가 다름

console.log('obj1의 name과 obj2의 name 같은가요? ==', obj1.name == obj2.name);
//true

const obj3 = obj2; 
console.log('obj3과 obj2는 같은가요? ==', obj3 == obj2);    //동일한 메모리주소







