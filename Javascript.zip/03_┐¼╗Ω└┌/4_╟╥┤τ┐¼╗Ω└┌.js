/*
  할당(대입)연산자 Assigment operator
*/

let a = 1;
a += 2;   //a = a + 2;
console.log(a);
a -= 2;   //a = a - 2;
console.log(a);
a *= 2;   //a = a * 2;
console.log(a);



let b = '오늘부터 ';
b += '우리는';
console.log(b);


