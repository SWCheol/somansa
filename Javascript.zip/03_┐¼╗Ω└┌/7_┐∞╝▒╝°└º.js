/*
  연산자 우선순위(priority)

*/

let a = 2;
let b = 3;
let result = a + b * 4;     //곱셈, 나누기가 먼저 
console.log(result);  //14

result = (a + b) * 4;       //()부터 먼저 계산
console.log(result);  //20

result = a++ + b + 4;      //연산을 끝낸뒤 ++로 추가해준다
console.log(result);    //9
console.log(a); //3
 
result = a++ + b * 4;
console.log(result);    //15
console.log(a); //4

