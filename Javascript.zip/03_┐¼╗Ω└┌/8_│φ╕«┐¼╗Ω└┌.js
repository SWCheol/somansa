/*
  논리연산자 Logical operator

  &&   (and) 그리고
  ||   (or) 또는
  !   (not) 부정,단항연산자에서 온것
  !!   블리언값으로 변환
*/
