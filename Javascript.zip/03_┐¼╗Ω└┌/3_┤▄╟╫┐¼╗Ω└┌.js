/*
  단항연산자 Unary operator 
  +(양) / -(음) / !(부정)
*/

let a = 5;
a = -a;         //-1*5
console.log(a);
a = -a; 
console.log(a);

a = +a; 
console.log(a);   //그대로 5


let bool = true;
console.log(bool);
console.log(!bool);     //false
console.log(!!bool);   //true

// + 숫자가 아닌 타입들을 숫자로 변환하면 어떤 값이 나오는지 확인 가능
console.clear();

console.log(+false);      //false는 0으로 간주
console.log(+null);       //0
console.log(+'');         //0

console.log(+true);       //1
console.log(+'adf');      //NaN (Nat a Number) 
console.log(+undefined);  //NaN (Nat a Number)  

console.log(!1); 
console.log(!!1);    //!값을 boolean타입으로 변환



