/*
  산술연산자 + - * / % **
*/

let num1 = 5;
let num2 = 3; 
console.log('num1과 num2를 더해주면', num1 + num2);
console.log('num1에서 num2를 빼주면', num1 - num2);
console.log('num1와 num2를 곱해주면', num1 * num2);
console.log('num2에서 num1를 나눠주면', num1 / num2);
console.log('num2에서 num1를 나눠주고 남은 값', num1 % num2);
console.log('num1을 num2번 곱한값', num1 ** num2);    //ES7방식에 추가된거


// + 연산자 주의점 - 문자열과 문자열, 숫자열과 문자열을 더하면 그냥 나열, 문자결합연산자
let text = '빨간색' + '운동화';
console.log(text);

let text2 = 25 + '편의점';   //숫자열 + 문자열 -> 문자열로 변환
console.log(text2);


//${변수} : 템플릿 문자열   / + (문자결합연산자) 대신에 사용, 백틱(백쿼드)``와 함께 사용

let subject, score;  
subject = 'Javascript';
score = 95;
console.log(subject + ' 과목 성적은? ' + score + '점 입니다');
console.log('${subject}  과목 성적은?  ${score} 점 입니다');
console.log(`${subject}  과목 성적은?  ${score} 점 입니다`);




