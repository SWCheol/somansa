/*
  static, 정적 프로퍼티, 매서드
  재사용성을 높이는 방법
  클래스에 한번만 만들어 지고 각 인스턴스에는 들어있지 않음 
*/

//클래스
class Fruit {     //함수명은 대문자로 시작(이름,색상,이모지)
  static taste = '맛있어!';     //고정된 프로퍼티 만듦

  constructor(aa,bb,cc){      
    this.name = aa;
    this.color = bb;
    this.emoji = cc;
  }
  //클래스 레벨의 매서드
  static maden(){
    return new Fruit('banana','yellow','🍌');
  }

  //인스턴스 레벨의 매서드
  display = () => { //this필요X
    console.log(`${this.name}:${this.emoji}`);
  }
}

const aaa = Fruit.maden();
console.log(aaa);
console.log(Fruit.taste);


const cherry = new Fruit('cherry','red','🍒');
//cherry는 Fruit 클래스의 인스턴스이다
const grape = new Fruit('grape','purple','🍇');
const melon = new Fruit('melon','light green','·🍈');

console.log(cherry);
console.log(grape);
console.log(melon);
console.log(grape.emoji);   //일반 객체처럼 사용
melon.display();