/* 접근자 프로퍼티 Accessor property
    -> 변수처럼 보이지만 실제로는 함수
    함수앞에 get
 */

class Student {
  constructor(firstName, lastName){
    this.aa = firstName;
    this.bb = lastName;
    //this.fullName = `${this.bb} ${this.aa}`;   -인자를 바꿨을때 업데이트가 안됨
  }
  get fullName(){
    return `get은 ${this.bb}${this.aa}`
  }

  set fullName(value){
    console.log('set은',value);
  }
}

const member = new Student('지현','전');  
console.log(member.aa);

//console.log(member.fullName()); 
/* 함수형식으로 호출 - 프로퍼티처럼 하고 싶음 ->프로퍼티 형식으로 
*/
member.aa = '수연';
console.log(member.fullName); 

member.fullName = '강동원';   //set 호출