/*
  객체지향 프로그래밍   
    1) 생성자함수(고전적 방식)
    2) 클래스 - 객체를 생성할 수 있는 템플릿
*/

//클래스
class Fruit {     //함수명은 대문자로 시작(이름,색상,이모지)
  constructor(aa,bb,cc){      
    this.name = aa;
    this.color = bb;
    this.emoji = cc;
  }
  display = () => { //this필요X
    console.log(`${this.name}:${this.emoji}`);
  }
}



// 생성자 함수랑 사용법 동일 
// 인스턴스 - 클래스를 통해서 만들어진 객체
const cherry = new Fruit('cherry','red','🍒');
//cherry는 Fruit 클래스의 인스턴스이다
const grape = new Fruit('grape','purple','🍇');
const melon = new Fruit('melon','light green','·🍈');

console.log(cherry);
console.log(grape);
console.log(melon);
console.log(grape.emoji);   //일반 객체처럼 사용
melon.display();