/*
  비공개로 사용, 접근제어자- 캡슐화(외부에서 수정 못하게)
  private/ public(기본)
*/

class Fruit {     //함수명은 대문자로 시작(이름,색상,이모지)
  #name;
  #type = '과일';


  constructor(aa,bb,cc){      
    this.#name = aa;
    this.color = bb;
    this.emoji = cc;
  }
  display = () => { //this필요X
    console.log(`${this.#name}:${this.emoji}`);
  }
}


const cherry = new Fruit('cherry','red','🍒');
console.log(cherry);
console.log(cherry.name);
console.log(cherry.type);   //undefined -가져올 수 없음
cherry.display();