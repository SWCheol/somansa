/*
  앞에 한 부분이 원시데이타/ 지금부터는 object
  object(객체)  - 복합데이터
*/

// let name = 'apple';
// let color = 'red';
// let display = '🍎';

let apple = { 
  name: 'apple', 
  color: 'red', 
  display: '🍎',
}
console.log(apple);
console.log(apple.display);
console.log(apple.color);

let nuri = {
  name: 'Nuri',
  type: 'cat',
  hometown: 'street',
  display:'🐱'
}

console.log(nuri);
console.log(nuri.display);

