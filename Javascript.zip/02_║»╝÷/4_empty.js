// null, undefined

let vari;
console.log(vari);  
//undefined. 메모리상 어떤 데이터도 들어있지 않음

vari = null;  //변수가 비었다고 선언
console.log(vari);  

let activeI;    //변수안에 내용이 있는지 없는지 모르는 상태
activeI = null; //변수 안 내용이 없는 상태    
console.log(activeI);  

console.log(typeof null); //object라고 표시 
console.log(typeof undefined); //undefined라고 표시


