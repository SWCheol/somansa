/* 숫자열 -숫자는 아무거나 다 됨*/
let integer = 123;    //정수    
let negative = -123;  //음수
let double = 1.23;    //실수

console.log('정수',integer);
console.log('음수',negative);
console.log('실수',double);

console.log(0/123);   //0
console.log(123/0);   //Infinity
console.log(123/-0);   //-Infinity
console.log(123/'aaa');   //NaN   (Not a Number)