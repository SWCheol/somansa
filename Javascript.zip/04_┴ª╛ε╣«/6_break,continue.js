/*
  반복문 제어; break,continue
*/


for(let i = 0; i<20; i++){

  if (i === 10){
    //continue;   //이걸 만나면 아래(같은 블록안의 코드)를 무시하고 바로 다음for문으로 넘어감
    console.log('i가 10이 되었어요!!!!');
    break;    //반복문 종료
  }
  console.log(i);
}