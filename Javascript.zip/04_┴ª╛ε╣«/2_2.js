/* 
  num의 숫자가 짝수이면 👍, 홀수이면 👎이 출력되게 
*/

let num = 5; 

// if ( num % 2 === 0) {
//   console.log('짝수입니다!!! 👍')
// } else {
//   console.log('홀수에요.. 👎')
// }

//num % 2 === 0 ? console.log('짝수입니다!!! 👍') : console.log('홀수에요.. 👎');

let aaa = num % 2 === 0 ? '짝수입니다!!! 👍':'홀수에요.. 👎';
console.log(aaa);