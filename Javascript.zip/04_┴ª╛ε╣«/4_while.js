/* 반복문 loop statment
https://developer.mozilla.org/ko/docs/Learn/JavaScript/Building_blocks/Looping_code
  

while(조건){
    조건에 만족할때 계속 실행
  }  
  
*/
let num = 1;
while(num <= 10 ){
  console.log( num );
  num++;
}