/*
  생성자 함수 (construction function) 객체를 만드는 역할을 하는 함수
  */



/*   비슷한 객체가 반복 ㅠㅠ  
let peach = {
  name : 'peach',
  color: 'pink',
  display: function(){
      console.log(`${this.name}:🍑`);
    }
}

let banana = {
  name : 'banana',
  color: 'yellow',
  display: function(){
      console.log(`${this.name}:🍌`);
    }
}
let cherry = {
  name : 'cherry',
  color: 'red',
  display: function(){
      console.log(`${this.name}:🍒`);
    }
}
*/

//생성자함수 템플릿
function Fruit(aa,bb,cc){     //함수명은 대문자로 시작(이름,색상,이모지)
  this.name = aa;
  this.color = bb;
  this.emoji = cc;
  this.display = function(){
    console.log(`${this.name}:${this.emoji}`);
  }
  return this;    //생략 가능, 생성자함수에서는 자동으로 리턴
};

const cherry = new Fruit('cherry','red','🍒');
const grape = new Fruit('grape','purple','🍇');
const melon = new Fruit('melon','light green','·🍈');

//항상 new를 붙여서 실행, 정해진 템플릿을 이용해서 원하는 데이터만 전달

console.log(cherry);
console.log(grape);
console.log(melon);
console.log(grape.emoji);   //일반 객체처럼 사용
melon.display();
