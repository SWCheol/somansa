/* 축약형 */


const x = 0;
const y = 0;

/*
const ccc = {
  x : x,
  y : y,
} 
  -- 키 이름과 밸류(참조하고 있는 변수)의 이름이 같으면 생략 가능
*/

const ccc = { 
  x,
  y,
}
console.log(ccc);



function ddd(name, age){
  return{
    //name:name,      //키와 밸류가 같을때
    //age:age,
    name,
    age
  }
}


console.log(ddd('누리','5'));