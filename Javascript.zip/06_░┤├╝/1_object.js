/*
  객체 Object  - 복합데이터, 그룹화 시킴
  -- 속성(property)   :객체내의 변수, 특징
  -- 매서드(method)   :객체의 일부로 선언된 함수, 작업명령

  만드는법
  1. object literal { key: value }
  2. new Object()     - Object클라스를 이용
  3. Object.create()  - Object 클라스 안의 create함수 이용

  key - 문자, 숫자, 심볼...
  value - 원시값(문자, 숫자..), 객체(함수)
*/

let apple = {
  name : 'apple',
  price : 1000, 
  3: 1004 ,   
  'apple-color': 'red',
  display: function(){
      console.log(`${apple.name}:🍎`);
    }
}
// apple-color  -특수문자를 쓸 수 없음 but 문자열의 형태로 가능
// 숫자도 가능

//오브젝트, value값에 접근하기 위해서
console.log(apple);
console.log(apple.name);
console.log(apple['apple-color']);    //문자열은 .생략후 대괄호로(배열의 아이템처럼)
apple.display();

// apple.shape          -마침표 표기법 dot notaion
// apple['apple-color'] -대괄호 표기법 bracket notaion

