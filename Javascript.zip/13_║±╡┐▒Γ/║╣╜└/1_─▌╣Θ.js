function increaseAndPrint(n, callback){
  setTimeout(()=>{
    let increased = n + 1;
    console.log(increased);

    if(callback) {
      callback(increased) ; 
    }

  },2000)
}

increaseAndPrint(0,(n)=>{
  increaseAndPrint(n, (n)=>{ 
    increaseAndPrint(n, (n)=>{
      increaseAndPrint(n, (n)=>{
        increaseAndPrint(n, (n)=>{
          increaseAndPrint(n, (n)=>{
            console.log('작업 끝')
          })  
        })  
      }) 
    })
  })
});

// function increaseAndPrint(n, callback) {
//   setTimeout(() => {
//     const increase = n + 1;
//     console.log("settimeout!", increase);

//     if (callback) {
//       console.log("callback!", increase);
//     }
//   }, 1000);

//   if (n < 10) {
//     return increaseAndPrint(n + 1);
//   } else {
//     return;
//   }
// }

// increaseAndPrint(0);