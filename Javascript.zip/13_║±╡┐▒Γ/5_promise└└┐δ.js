function fetchEgg(chicken){
  //return new Promise((resolve, reject))
  return Promise.resolve(`${chicken} --> 🥚`);  //위에꺼 대신에 스태틱메소드resolve
}

function freyEgg(egg){
  return Promise.resolve(`${egg} --> 🍳`);
}

function getChicken(){
  return Promise.reject(new Error('치킨을 가지고 올 수 없음!!'));
  //return Promise.resolve(`🌿 --> 🐔`);
}


getChicken()
.catch((error)=> { console.log(error.name); return '🌻'})
.then(fetchEgg)
.then(freyEgg)
.then(console.log)


