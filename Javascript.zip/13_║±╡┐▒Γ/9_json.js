//JSON : 자바스크립트에서 사용되는 객체를 서버와 주고받기 편한 문자열
//오브젝트 형태의 텍스트포맷

const nuri = {
  name : 'nuri',
  age : 3,
  type : 'cat',
  eat : () => { console.log('냠냠') } 
}

console.log('오브젝트nuri',nuri);

const jj = JSON.stringify(nuri);
console.log('Json nuri',jj);
//json형태의 문자열로 변환(serializing)
//함수는 포함되지 않음. 객체의 프로퍼티만

const obj = JSON.parse(jj);
console.log('json을 다시 오브젝트로',obj);


