//then들이 중복으로 배치되고 더 복잡해짐 -> 깔끔하게
//비동적인 코드들이 동기적(절차적)으로 보이게 함

function getBanana(){
  return new Promise((resolve) => {
    setTimeout(() => { resolve('🍌') }, 3000)
  })  
}

function getApple(){
  return new Promise((resolve) => {
    setTimeout(() => { resolve('🍎') }, 5000)
  })  
}

function getOrange(){
  return Promise.reject(new Error('오렌지는 없어요 ㅠㅠ'))
}

//바나나와 사과를 가지고 와서 배열로
// getBanana()
// .then((aa) => getApple() 
//   .then((bb) => { return [aa, bb]})
//   )
// .then(console.log);   //3초+1초, 총 4초의 시간이 걸림 

async function fetchFruits(){ 
  const banana = await getBanana();
  const apple = await getApple();
  return [banana, apple]
}  
//async 붙이면 비동기, 프로미스가 호출, 내부를 동기적인 코드로 작성 가능하게
  
fetchFruits()
  .then(console.log)
;



