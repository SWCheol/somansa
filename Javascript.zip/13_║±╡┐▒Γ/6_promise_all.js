function getBanana(){
  return new Promise((resolve) => {
    setTimeout(() => { resolve('🍌') }, 3000)
  })  
}

function getApple(){
  return new Promise((resolve) => {
    setTimeout(() => { resolve('🍎') }, 1000)
  })  
}

function getOrange(){
  return Promise.reject(new Error('오렌지는 없어요 ㅠㅠ'))
}

//바나나와 사과를 가지고 와서 배열로
getBanana()
.then((aa) => getApple() 
  .then((bb) => { return [aa, bb]})
  )
.then(console.log);   //3초+1초, 총 4초의 시간이 걸림 

//Promise.all 한번에 모든 Promise들을 실행, 
Promise.all([getBanana(),getApple()])
.then(fruits => console.log('all',fruits));   //3초 걸림

//Promise.race Promise들 중에 제일 빨리 수행된것이 이김
Promise.race([getBanana(),getApple()])
.then(fruit => console.log('race',fruit));


Promise.all([getBanana(),getApple(),getOrange()])
.then(fruits => console.log('all-error',fruits))
.catch(console.log);

//Promise.allSettled 여러 Promise들을 동시에 처리, 실패한 프로미스가 있어도 무조건 실행
Promise.allSettled([getBanana(),getApple(),getOrange()])
.then(fruits => console.log('allSettled',fruits))
.catch(console.log);




