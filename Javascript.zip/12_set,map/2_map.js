/*
  map - key, Value, 키는 중복 불가
        배열과 달리 순서(index) 없음, set과 달리 밸류 중복 가능
        오브젝트와 비슷
*/

const map =  new Map([ ['key1', '🍎'],  ['key2', '🍌'] ]);    //배열 안에 또다른 배열
console.log('map은?',map)

//사이즈 확인
console.log('map 아이템의 갯수',map.size);



//존재하는지 확인(set과 동일), key로 확인  -boolean
console.log('map에 key1이 있냐?',map.has('key1'));
console.log('map에 key1이 있냐?',map.has('key6'));


//순회
map.forEach((aa,bb,cc) => console.log(aa,bb,cc));  //(밸류,키,map)

console.log('밸류만', map.values());
console.log('키만', map.keys());
console.log('전체', map.entries());

//찾기
console.log('key1의 value값은?', map.get('key1'));
console.log('key2의 value값은?', map.get('key2'));
console.log('key6의 value값은?', map.get('key6'));   //undefined

//추가
map.set('key3','🥝');
console.log('키위 추가', map);

//삭제 -key값 이용
map.delete('key3');
console.log('key3삭제', map);

//전부삭제
map.clear();
console.log('전부삭제', map);




