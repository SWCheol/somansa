/* 
  set  - 정보의 집합
  배열과 달리 순서(index)가 없음, Value만 있음, 아이템 중복 불가
*/

const set = new Set(['하늘', '바다', '산']);   //set생성
console.log(set);

console.log('set의 아이템 숫자 확인', set.size);
console.log('set의 아이템 존재 확인',set.has('산'));
console.log('set의 아이템 존재 확인',set.has(6));

//순회
set.forEach((aa) => console.log('forEach사용',aa));
for(const bb of set.values()){
  console.log('for of 사용',bb)
}

//추가
set.add(1004);
console.log('1004 추가',set);
set.add(1004);
console.log('1004 또 추가',set);  //아이템 중복 불가

//삭제
set.delete('바다');
console.log('바다 삭제',set);

//전부삭제
set.clear();
console.log('전부 삭제',set);


//오브젝트
const obj1 = { name:'🍔', price:2500 };
const obj2 = { name:'🍩', price:1000 };
const objs = new Set([obj1, obj2])
console.log('objs?',objs);

obj1.price = 1700;
console.log('obj1가격 인하',obj1);
console.log('obj1가격 인하 objs?',objs);
//shallow copy - 세트도 바뀜

const obj3= { name:'🥤', price:800 };
objs.add(obj3);
console.log('obj3 추가',objs);

console.log('entries????',objs.entries());




