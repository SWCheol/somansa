function add(a,b){
  a+b;  
}
// return을 명시하지 않으면 undefined 반환

const result = add(3,5);
console.log(result);


function write(ttt){
  console.log('글자가 나올까요?',ttt);
}
// 특정한 일 수행하거나 반환하지 않는 함수는 return생략 가능
write('texttexttexttexttext');

function print(num){
  if(num < 0){
    return;
    //조건에 맞으면 리턴으로 함수를 종료,  return undefined의 축약
  }
  console.log(num);
}

print(-12);