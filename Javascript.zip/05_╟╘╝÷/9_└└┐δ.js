/*
  *** 주어진 숫자만큼 0부터 나열하는 함수
      -두배값을 나열
  
*/

function iterate(max,action){
  for(let i=0; i<max; i++){
    action(i);
  }
}
function print(num){
  console.log(num)
}
function print2(num){
  console.log(num*2);   //짝수만 출력
}

iterate(20,print);
iterate(20,print2);
