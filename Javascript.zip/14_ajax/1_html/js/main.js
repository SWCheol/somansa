const xhr = new XMLHttpRequest();
//XMLHttpRequest() - 외부 데이터를 불러들이는 객체


xhr.onload = function(){
  if( xhr.status == 200 ){      //서버 응답이 정상이라면 (Http status code) 
    document.getElementById('content').innerHTML =  xhr.responseText;
  //가져온 데이터를 #content에 넣어준다
  }  
}



xhr.open('get','data.html',true);   //요청을 준비하다
xhr.send();        //요청을 전송한다