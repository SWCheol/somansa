/* 문자열 */

const textObj = new String('Hello World!'); //객체로
const ttt = 'Hello Korea!';                 //원시타입으로
console.log(textObj);
console.log(ttt);

console.log('ttt문자 수는?',ttt.length);   //.을 찍으면 사용가능한 모든 프로퍼티와 매서드를 살펴볼 수있다 
console.log('첫번째 문자',ttt[0]);          //배열처럼 인덱스를 이용해서 몇번째 문자인지 알아올 수 있다
console.log('다섯번째 문자',ttt[4]);
console.log('첫번째 문자',ttt.charAt(0));   //오브젝트 방식으로 첫번째 문자 알아오기

console.log('l은 몇번째 있는 문자?',ttt.indexOf('l'));
console.log('o은 뒤에서부터 몇번째 있는 문자?',ttt.lastIndexOf('o'));
//없는 문자를 찾을때는 -1

console.log('특정문자가 있는지 확인(블린)',ttt.includes('Ko'));

console.log('특정문자 h로 시작하는지 안하는지(블린)',ttt.startsWith('h'));
console.log('특정문자 H로 시작하는지 안하는지(블린)',ttt.startsWith('H'));
console.log('특정문자 !로 끝나는지(블린)',ttt.endsWith('!'));

console.log('대문자로',ttt.toUpperCase());
console.log('소문자로',ttt.toLowerCase());

console.log('2문자를 잘라서(빼고) 가져옴',ttt.slice(2));        // llo Korea!
console.log('뒤에서 부터 2문자를 잘라 가져옴',ttt.slice(-2));   // a!


const aa = '       space         '
console.log(aa);
console.log(aa.trim());

const longTxt = 'Fly to the moon';
console.log('스페이스를 기준으로 문자열을 끊어준다',longTxt.split(' '));
console.log('스페이스를 기준으로 문자열을 끊어주고, 2개만가져옴',longTxt.split(' ',2));


















